package com.TauberSchools.EscolaDeGeniosTauber;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EscolaDeGeniosTauberApplication {

	public static void main(String[] args) {
		SpringApplication.run(EscolaDeGeniosTauberApplication.class, args);
	}

}
