package com.TauberSchools.EscolaDeGeniosTauber;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EscolaDeGeniosTauberApplicationTests {

	@Test
	void contextLoads() {
	}

}
