package com.tauber.TauberBlog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TauberBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
